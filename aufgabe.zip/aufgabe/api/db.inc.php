<?php
$DbInfo= [
    "DB_HOST"=>"localhost"
    ,"DB_USER"=>"root"
    ,"DB_PASS"=>"ZuDQOqtmqlFLeHQ2x39c"
    ,"DB_NAME"=>"myblog"
    ,"DB_PORT"=>"3306"
    ,"DB_FORMAT"=>"utf8"
];