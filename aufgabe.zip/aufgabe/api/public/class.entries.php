<?php

class Entries extends api {
    public function __construct($server) {
        $this->dbinstance=$server->dbinstance;
        $this->out=$server->output;
        $this->user=$server->sessionProcessor;
        $this->table="entries";
        parent::__construct($server);
    }
    public function load($params) {
        $response=parent::load($params);
        $this->out->ok($response);
    }
    public function read($params) {
        $response=parent::read($params);
        $this->out->ok($response);
    }
    public function insert($params) {
        $lastID=parent::insert($params);
        $response=parent::load(array($this->primaryKey=>$lastID));
        $this->out->ok($response);
    }
    public function readAll($params) {
        return parent::loadAll();
    }
    public function update($params) {
      parent::update($params);
      $response=parent::load($params);
      $this->out->ok($response);
    }
}